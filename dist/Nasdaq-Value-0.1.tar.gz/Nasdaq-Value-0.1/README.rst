# Nasdaq-Value

A simple GUI which gives the nasdaq value of any company once you input the nasdaq symbol of that company.
